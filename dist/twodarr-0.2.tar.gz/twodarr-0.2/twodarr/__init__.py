from check_bound import check_bound
from all_adj import all_adj
from some_adj import some_adj